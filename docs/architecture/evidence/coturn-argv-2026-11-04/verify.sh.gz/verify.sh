#!/bin/bash
set -euo pipefail
export LINGXI_TURN_BIND_IP=127.0.0.1 LINGXI_TURN_ADVERTISED_IP=127.0.0.1
project=lingxi-rtc021-argv-check
baseline=/private/tmp/round5-coturn-argv-baseline-compose.yaml
git show 2034414b827e8819766e738e47c4f41ccac60696:packages/webrtc/compose.turn.yaml > "$baseline"
docker compose -p "$project" -f "$baseline" config --format json > /private/tmp/round5-coturn-argv-before.json
docker compose -p "$project" -f compose.turn.yaml config --format json > /private/tmp/round5-coturn-argv-after.json
python3.13 - <<'PY'
import json
before=json.load(open('/private/tmp/round5-coturn-argv-before.json'))['services']['turn']
after=json.load(open('/private/tmp/round5-coturn-argv-after.json'))['services']['turn']
assert before.pop('entrypoint') is None
assert after.pop('entrypoint') == ['turnserver']
assert before == after, 'another fixture setting changed'
print('Compose comparison: only entrypoint changed; all other service settings identical')
PY
if [ -n "$(docker ps -aq --filter "label=com.docker.compose.project=$project")" ]; then
  printf 'Fixture project already exists; leaving it untouched.\n' >&2
  exit 1
fi
fixture_started=0
cleanup() {
  status=$?
  trap - EXIT
  if [ "$fixture_started" = 1 ]; then
    docker compose -p "$project" -f compose.turn.yaml logs --no-color > /private/tmp/round5-coturn-argv-fixture.log 2>&1 || true
    docker compose -p "$project" -f compose.turn.yaml down || status=1
  fi
  exit "$status"
}
trap cleanup EXIT
fixture_started=1
docker compose -p "$project" -f compose.turn.yaml up -d --no-build --pull never
fixture_id=$(docker compose -p "$project" -f compose.turn.yaml ps -q turn)
python3.13 - "$fixture_id" <<'PY'
import json,subprocess,sys
c=json.loads(subprocess.check_output(['docker','inspect',sys.argv[1]],text=True))[0]
report={'image_id':c['Image'],'path':c['Path'],'args':c['Args'],'entrypoint':c['Config']['Entrypoint'],'cmd':c['Config']['Cmd'],'port_bindings':c['HostConfig']['PortBindings'],'readonly_rootfs':c['HostConfig']['ReadonlyRootfs'],'cap_add':c['HostConfig']['CapAdd'],'cap_drop':c['HostConfig']['CapDrop'],'security_opt':c['HostConfig']['SecurityOpt'],'tmpfs':c['HostConfig']['Tmpfs']}
open('/private/tmp/round5-coturn-argv-container.json','w').write(json.dumps(report,indent=2)+'\n')
assert report['image_id']=='sha256:c29135c08565810d37053f384584392b7c24b69570fc81a721b878d6fe63e04e'
assert report['path']=='turnserver' and report['entrypoint']==['turnserver']
assert report['args'][:2]==['-n','-v'] and all(report['args'])
ports=report['port_bindings']; expected={'3478/tcp','3478/udp'}|{f'{n}/udp' for n in range(50100,50116)}
assert set(ports)==expected
for name,bindings in ports.items():
 assert len(bindings)==1 and bindings[0]['HostIp']=='127.0.0.1' and bindings[0]['HostPort']==name.split('/')[0]
assert report['readonly_rootfs'] and report['cap_drop']==['ALL'] and report['cap_add']==['CAP_NET_BIND_SERVICE']
assert 'no-new-privileges:true' in report['security_opt']
assert set(report['tmpfs'])=={'/var/lib/coturn','/tmp','/var/run'}
open('/private/tmp/round5-coturn-argv-container.json','w').write(json.dumps(report,indent=2)+'\n')
print('Container inspection: exact -n/-v argv, loopback-only host ports, read-only root, caps and tmpfs verified')
PY
/Users/luolingfeng/lingxi/.buildcache/media-round5-rtc021-check/debug/deps/lingxi_webrtc_core-0eb9ebf20220cff7 --ignored --test-threads=1 --nocapture 2>&1 | tee /private/tmp/round5-coturn-argv-tests.log
docker compose -p "$project" -f compose.turn.yaml logs --no-color > /private/tmp/round5-coturn-argv-fixture.log
if rg -n 'Unknown argument|Cannot find config file' /private/tmp/round5-coturn-argv-fixture.log; then
  printf 'Unexpected Coturn configuration warning found.\n' >&2
  exit 1
fi
printf 'Coturn log: no unknown argument and no missing-default-config warning.\n'
